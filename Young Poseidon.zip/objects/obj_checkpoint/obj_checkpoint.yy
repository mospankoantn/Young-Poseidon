{
  "$GMObject": "",
  "%Name": "obj_checkpoint",
  "eventList": [
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 0,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 3,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 8,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    }
  ],
  "managed": true,
  "name": "obj_checkpoint",
  "overriddenProperties": [],
  "parent": {
    "name": "System",
    "path": "folders/Объекты/System.yy"
  },
  "parentObjectId": null,
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": {
    "name": "spr_checkpoint",
    "path": "sprites/spr_checkpoint/spr_checkpoint.yy"
  },
  "spriteMaskId": {
    "name": "spr_test_64",
    "path": "sprites/spr_test_64/spr_test_64.yy"
  },
  "visible": true
}
