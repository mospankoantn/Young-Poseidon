{
  "$GMObject": "",
  "%Name": "obj_pickup_scythe_reward",
  "eventList": [
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 0,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 10,
      "eventType": 7,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    }
  ],
  "managed": true,
  "name": "obj_pickup_scythe_reward",
  "overriddenProperties": [],
  "parent": {
    "name": "Item",
    "path": "folders/Объекты/Item.yy"
  },
  "parentObjectId": {
    "name": "obj_pickup_weapon_base",
    "path": "objects/obj_pickup_weapon_base/obj_pickup_weapon_base.yy"
  },
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": {
    "name": "spr_weapon_scythe",
    "path": "sprites/spr_weapon_scythe/spr_weapon_scythe.yy"
  },
  "spriteMaskId": {
    "name": "spr_weapon_collision",
    "path": "sprites/spr_weapon_collision/spr_weapon_collision.yy"
  },
  "visible": true
}
