 /// @description Сандаль Гермеса: перманентно збільшує швидкість гравця
 // obj_pickup_sandal — Collision with obj_player

if (can_pickup)
{
    world_state_mark_instance(id, "pickup");
    with (other)
    {
        perm_spd_bonus += 0.3;   
    }
    instance_destroy();
}
