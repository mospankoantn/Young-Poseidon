{
  "$GMSprite": "v2",
  "%Name": "spr_giant_crab",
  "bboxMode": 0,
  "bbox_bottom": 63,
  "bbox_left": 0,
  "bbox_right": 63,
  "bbox_top": 0,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "fbe36973-98bc-471e-b115-7793e256029c",
      "name": "fbe36973-98bc-471e-b115-7793e256029c",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 64,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "b10d8c83-bf42-4ea1-ba70-08da523cc510",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "b10d8c83-bf42-4ea1-ba70-08da523cc510",
      "opacity": 100.0,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_giant_crab",
  "nineSlice": null,
  "origin": 7,
  "parent": {
    "name": "Giant Crab",
    "path": "folders/Спрайты/Enemies/Giant Crab.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_giant_crab",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 1.0,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_giant_crab",
    "playback": 1,
    "playbackSpeed": 30.0,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "fbe36973-98bc-471e-b115-7793e256029c",
                    "path": "sprites/spr_giant_crab/spr_giant_crab.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "a32f92a3-ffff-438e-ad58-a649395fabc2",
              "IsCreationKey": false,
              "Key": 0.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1.0,
    "xorigin": 32,
    "yorigin": 64
  },
  "swatchColours": null,
  "swfPrecision": 2.525,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 64
}
