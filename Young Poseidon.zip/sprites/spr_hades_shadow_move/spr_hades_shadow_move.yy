{
  "$GMSprite": "v2",
  "%Name": "spr_hades_shadow_move",
  "bboxMode": 2,
  "bbox_bottom": 95,
  "bbox_left": 0,
  "bbox_right": 95,
  "bbox_top": 0,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "3df3507a-deb6-476f-8e31-8255f6796fd8",
      "name": "3df3507a-deb6-476f-8e31-8255f6796fd8",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "50039228-d2a8-4467-bb58-d5005d0de363",
      "name": "50039228-d2a8-4467-bb58-d5005d0de363",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "215e8854-f0a0-4b64-8067-c62a5cef50fe",
      "name": "215e8854-f0a0-4b64-8067-c62a5cef50fe",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "0a2d9441-1517-49f9-8dd2-d21913e3a88f",
      "name": "0a2d9441-1517-49f9-8dd2-d21913e3a88f",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 96,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "4db52729-860d-4ba1-905e-6707551ddb48",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "4db52729-860d-4ba1-905e-6707551ddb48",
      "opacity": 100.0,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_hades_shadow_move",
  "nineSlice": null,
  "origin": 9,
  "parent": {
    "name": "Hades Shadow",
    "path": "folders/Спрайты/Enemies/Hades Shadow.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_hades_shadow_move",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 4.0,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_hades_shadow_move",
    "playback": 1,
    "playbackSpeed": 10.0,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "3df3507a-deb6-476f-8e31-8255f6796fd8",
                    "path": "sprites/spr_hades_shadow_move/spr_hades_shadow_move.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "dbc52e40-4b3d-468a-a1fe-fab6006bec34",
              "IsCreationKey": false,
              "Key": 0.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "50039228-d2a8-4467-bb58-d5005d0de363",
                    "path": "sprites/spr_hades_shadow_move/spr_hades_shadow_move.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "a83fad68-dc30-4b58-9c0e-1658e08c4496",
              "IsCreationKey": false,
              "Key": 1.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "215e8854-f0a0-4b64-8067-c62a5cef50fe",
                    "path": "sprites/spr_hades_shadow_move/spr_hades_shadow_move.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "aa86ab6c-f434-4a16-b38b-44d59d8a8a27",
              "IsCreationKey": false,
              "Key": 2.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "0a2d9441-1517-49f9-8dd2-d21913e3a88f",
                    "path": "sprites/spr_hades_shadow_move/spr_hades_shadow_move.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "34ed7ddc-388e-440d-891b-40cf5f000978",
              "IsCreationKey": false,
              "Key": 3.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1.0,
    "xorigin": 48,
    "yorigin": 90
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 96
}
