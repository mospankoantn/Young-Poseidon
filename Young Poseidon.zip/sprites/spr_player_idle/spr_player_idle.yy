{
  "$GMSprite": "v2",
  "%Name": "spr_player_idle",
  "bboxMode": 2,
  "bbox_bottom": 87,
  "bbox_left": 40,
  "bbox_right": 88,
  "bbox_top": 24,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "1403d1d5-5378-4035-a1fa-dce0f5bac9d0",
      "name": "1403d1d5-5378-4035-a1fa-dce0f5bac9d0",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "02d2344d-5551-43c8-a553-e53df52d3cf7",
      "name": "02d2344d-5551-43c8-a553-e53df52d3cf7",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "6bb5014e-5b95-4eb0-b4ff-289019052e83",
      "name": "6bb5014e-5b95-4eb0-b4ff-289019052e83",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "b3cb0016-fc76-4560-824b-7d783c3f4ae5",
      "name": "b3cb0016-fc76-4560-824b-7d783c3f4ae5",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "5b0290ce-5e59-4d10-9d9a-74657456e6f0",
      "name": "5b0290ce-5e59-4d10-9d9a-74657456e6f0",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "1cca2a79-2c06-4e50-a351-c66f4c2d09fa",
      "name": "1cca2a79-2c06-4e50-a351-c66f4c2d09fa",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 96,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "b6843f49-169e-411b-8290-c6d458b8a365",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "b6843f49-169e-411b-8290-c6d458b8a365",
      "opacity": 100.0,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_player_idle",
  "nineSlice": null,
  "origin": 9,
  "parent": {
    "name": "Player",
    "path": "folders/Спрайты/Player.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_player_idle",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 6.0,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_player_idle",
    "playback": 1,
    "playbackSpeed": 8.0,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "1403d1d5-5378-4035-a1fa-dce0f5bac9d0",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "73976749-5700-4759-a18c-9fb8fd91cfb1",
              "IsCreationKey": false,
              "Key": 0.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "02d2344d-5551-43c8-a553-e53df52d3cf7",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "848c91c5-08c0-4ca8-9538-00282e4f47b7",
              "IsCreationKey": false,
              "Key": 1.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "6bb5014e-5b95-4eb0-b4ff-289019052e83",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "ec34a472-fb6d-4512-bbb3-6cac037c8f4e",
              "IsCreationKey": false,
              "Key": 2.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "b3cb0016-fc76-4560-824b-7d783c3f4ae5",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "0bf76fcc-a10e-4ce7-9c94-9ea08be9ad41",
              "IsCreationKey": false,
              "Key": 3.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "5b0290ce-5e59-4d10-9d9a-74657456e6f0",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "1f109f55-e216-4cf6-84c2-8303abb22bd6",
              "IsCreationKey": false,
              "Key": 4.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "1cca2a79-2c06-4e50-a351-c66f4c2d09fa",
                    "path": "sprites/spr_player_idle/spr_player_idle.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "4eb033f6-f044-49be-9297-db55b981696a",
              "IsCreationKey": false,
              "Key": 5.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1.0,
    "xorigin": 64,
    "yorigin": 88
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 128
}
