{
  "$GMSprite": "v2",
  "%Name": "spr_player_attack",
  "bboxMode": 2,
  "bbox_bottom": 87,
  "bbox_left": 40,
  "bbox_right": 88,
  "bbox_top": 24,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "7053352b-8a40-4660-a0d2-2101ab7f88f4",
      "name": "7053352b-8a40-4660-a0d2-2101ab7f88f4",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "1e04c4c3-805e-4558-93a9-75d3e45e2628",
      "name": "1e04c4c3-805e-4558-93a9-75d3e45e2628",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "4d513f9b-0894-4f8f-bc02-b2fec601192b",
      "name": "4d513f9b-0894-4f8f-bc02-b2fec601192b",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "5832d30d-9b9e-4309-81e1-6f00b930ab53",
      "name": "5832d30d-9b9e-4309-81e1-6f00b930ab53",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "33d18ece-fb8b-417b-9eeb-d0e96d3ec796",
      "name": "33d18ece-fb8b-417b-9eeb-d0e96d3ec796",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 96,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "7cd1a0e7-57be-43be-a13e-251e5a51af93",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "7cd1a0e7-57be-43be-a13e-251e5a51af93",
      "opacity": 100.0,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_player_attack",
  "nineSlice": null,
  "origin": 9,
  "parent": {
    "name": "Player",
    "path": "folders/Спрайты/Player.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_player_attack",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 5.0,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_player_attack",
    "playback": 1,
    "playbackSpeed": 18.0,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "7053352b-8a40-4660-a0d2-2101ab7f88f4",
                    "path": "sprites/spr_player_attack/spr_player_attack.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "d9e22ad3-58a3-4ecc-9f8b-60d34aa85c68",
              "IsCreationKey": false,
              "Key": 0.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "1e04c4c3-805e-4558-93a9-75d3e45e2628",
                    "path": "sprites/spr_player_attack/spr_player_attack.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "abaf0016-9a1b-458d-89c3-b1ba6469d73a",
              "IsCreationKey": false,
              "Key": 1.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "4d513f9b-0894-4f8f-bc02-b2fec601192b",
                    "path": "sprites/spr_player_attack/spr_player_attack.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "bbd996a9-6124-4ff0-8b2b-26c5aefd7094",
              "IsCreationKey": false,
              "Key": 2.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "5832d30d-9b9e-4309-81e1-6f00b930ab53",
                    "path": "sprites/spr_player_attack/spr_player_attack.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "cc60479b-2c7b-4822-bc4d-e2f06cf6877d",
              "IsCreationKey": false,
              "Key": 3.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "33d18ece-fb8b-417b-9eeb-d0e96d3ec796",
                    "path": "sprites/spr_player_attack/spr_player_attack.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "eec2cb7d-2e0d-4bdd-9c99-ef6fd2cffb71",
              "IsCreationKey": false,
              "Key": 4.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1.0,
    "xorigin": 64,
    "yorigin": 88
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 128
}
