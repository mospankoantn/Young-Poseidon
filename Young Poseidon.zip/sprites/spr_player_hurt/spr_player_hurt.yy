{
  "$GMSprite": "v2",
  "%Name": "spr_player_hurt",
  "bboxMode": 2,
  "bbox_bottom": 87,
  "bbox_left": 40,
  "bbox_right": 88,
  "bbox_top": 24,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "4ed8731a-64cf-44b7-9a18-cf1a6463f66c",
      "name": "4ed8731a-64cf-44b7-9a18-cf1a6463f66c",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "b100a721-a587-443f-a968-e153e6708b71",
      "name": "b100a721-a587-443f-a968-e153e6708b71",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "34897c75-6a30-467c-9f41-e418ad927f55",
      "name": "34897c75-6a30-467c-9f41-e418ad927f55",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "98d7c4c4-31b0-4e4d-9b1e-e1ebfd70c943",
      "name": "98d7c4c4-31b0-4e4d-9b1e-e1ebfd70c943",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "fb0625d2-ec04-4662-8e51-0967a6355938",
      "name": "fb0625d2-ec04-4662-8e51-0967a6355938",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    },
    {
      "$GMSpriteFrame": "v1",
      "%Name": "ab0bbf27-1ac5-4933-833d-c654336fb614",
      "name": "ab0bbf27-1ac5-4933-833d-c654336fb614",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 96,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "09821829-3574-408d-a65e-9b1ab2618d71",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "09821829-3574-408d-a65e-9b1ab2618d71",
      "opacity": 100.0,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_player_hurt",
  "nineSlice": null,
  "origin": 9,
  "parent": {
    "name": "Player",
    "path": "folders/Спрайты/Player.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_player_hurt",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0.0,
    "backdropYOffset": 0.0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 6.0,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_player_hurt",
    "playback": 1,
    "playbackSpeed": 18.0,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "4ed8731a-64cf-44b7-9a18-cf1a6463f66c",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "ab26d195-6277-436e-b118-51edf7b61c76",
              "IsCreationKey": false,
              "Key": 0.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "b100a721-a587-443f-a968-e153e6708b71",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "42943d73-9b35-4e9d-8f5e-a0d8479ddad3",
              "IsCreationKey": false,
              "Key": 1.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "34897c75-6a30-467c-9f41-e418ad927f55",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "61ac674d-05fe-49db-a58b-f878f42641d6",
              "IsCreationKey": false,
              "Key": 2.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "98d7c4c4-31b0-4e4d-9b1e-e1ebfd70c943",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "40ce3277-8d78-4a3c-8e62-d719b17b45ef",
              "IsCreationKey": false,
              "Key": 3.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "fb0625d2-ec04-4662-8e51-0967a6355938",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "2fda8fe8-9bc5-45b6-933e-531eab5bc3af",
              "IsCreationKey": false,
              "Key": 4.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            },
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "ab0bbf27-1ac5-4933-833d-c654336fb614",
                    "path": "sprites/spr_player_hurt/spr_player_hurt.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "ed619a42-c611-4c9b-9b17-ec4432752195",
              "IsCreationKey": false,
              "Key": 5.0,
              "Length": 1.0,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1.0,
    "xorigin": 64,
    "yorigin": 88
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 128
}
