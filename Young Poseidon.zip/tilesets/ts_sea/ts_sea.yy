{
  "$GMTileSet": "v1",
  "%Name": "ts_sea",
  "autoTileSets": [],
  "macroPageTiles": {
    "SerialiseHeight": 0,
    "SerialiseWidth": 0,
    "TileSerialiseData": []
  },
  "name": "ts_sea",
  "out_columns": 8,
  "out_tilehborder": 2,
  "out_tilevborder": 2,
  "parent": {
    "name": "Tile Sets",
    "path": "folders/Tile Sets.yy"
  },
  "resourceType": "GMTileSet",
  "resourceVersion": "2.0",
  "spriteId": {
    "name": "spr_sea_tiles",
    "path": "sprites/spr_sea_tiles/spr_sea_tiles.yy"
  },
  "spriteNoExport": false,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "tileAnimationFrames": [],
  "tileAnimationSpeed": 15.0,
  "tileHeight": 64,
  "tilehsep": 0,
  "tilevsep": 0,
  "tileWidth": 64,
  "tilexoff": 0,
  "tileyoff": 0,
  "tile_count": 64
}
